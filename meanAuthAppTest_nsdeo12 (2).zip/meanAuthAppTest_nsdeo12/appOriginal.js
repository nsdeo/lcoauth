var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var request = require('request');
var cookieParser = require('cookie-parser');
var cors = require('cors');
var bodyParser = require('body-parser');
var parseJson = require('parse-json');
var routes = require('./routes/index');
var users = require('./routes/users');
var dishrouter = require('./routes/dishrouter');
var promorouter = require('./routes/promorouter');
var leaderrouter = require('./routes/leaderrouter');
//var customerRouter=require('./routes/customerRouter');
//var employeeRouter=require('./routes/employeeRouter');
var morgan = require('morgan'); // log requests to the console (express4)
var bodyParser = require('body-parser'); // pull information from HTML POST (express4)
//  var methodOverride = require('method-override'); // simulate DELETE and PUT (express4)
var fs = require('fs');
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var smtpPool = require('nodemailer-smtp-pool');
var fs = require('fs');
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var smtpPool = require('nodemailer-smtp-pool');
var js2xmlparser = require("js2xmlparser");
var fs = require('fs');
var builder = require('xmlbuilder');
var http = require('http');
var soap = require('soap');
var xml2js = require('xml2js');
var request = require('request');
var parser = require('xml2js');
//var xmlToJSON = require("xmlToJSON");
var xmltojson = require("xmltojson");
var xmlToJSON = require('xmlToJSON');
var dateFormat = require('dateformat');

var passport = require('passport');
 var methodOverride = require('method-override');
 var GitHubStrategy = require('passport-github2').Strategy;
var partials = require('express-partials');
var transporter = nodemailer.createTransport(
	smtpPool({
		host: 'localhost',
		port: 1025,
		ignoreTLS: true
	})
);


var alfabank = express();
alfabank.use(cors());
//alfabank.use(cookieSession({maxAge: 30 * 24 * 60 * 60 * 1000,keys: [keys.cookieKey]}));
  alfabank.use(passport.initialize());
  alfabank.use(passport.session());
var GITHUB_CLIENT_ID = "26fe8b247f20087d4f74";
var GITHUB_CLIENT_SECRET = "0a8c9f420aece4f6fcef0e7057abd9536fe83259";

passport.use(new GitHubStrategy({
    clientID: GITHUB_CLIENT_ID,
    clientSecret: GITHUB_CLIENT_SECRET,
    callbackURL: "http://localhost:3030/auth/github/callback"
  },
  function(accessToken, refreshToken, profile, done) {
	console.log("inside profile>>>>>>>>>>>>>>");
	// asynchronous verification, for effect...
    process.nextTick(function () {
		console.log("inside nextTick>>>>>>>>>>>>>>");
      
      // To keep the example simple, the user's GitHub profile is returned to
      // represent the logged-in user.  In a typical application, you would want
      // to associate the GitHub account with a user record in your database,
      // and return that user instead.
	 console.log("profile",profile) ;
	  return done(null, profile);
	  
    });
  }
));

passport.serializeUser(function(user, done) {
	done(null, user);
  });
  
  passport.deserializeUser(function(user, done) {
	done(null, user);
  });








var inf;
alfabank.use(morgan('dev'));
alfabank.use(bodyParser.urlencoded({
	'extended': 'true'
})); // parse application/x-www-form-urlencoded
alfabank.use(bodyParser.json()); // parse application/json
alfabank.use(bodyParser.json({
	type: 'application/vnd.api+json'
})); // parse application/vnd.api+json as json


var Ibc1 = require('ibm-blockchain-js'); //rest based SDK for ibm blockchain
var ibc = new Ibc1();



try {
	//this hard coded list is intentionaly left here, feel free to use it when initially starting out
	//please create your own network when you are up and running
	var manual = JSON.parse(fs.readFileSync('mycreds_docker_compose.json', 'utf8'));

	var peers = manual.credentials.peers;
	//console.log('loading hardcoded peers',peers);
	var users = null; //users are only found if security is on
	if (manual.credentials.users) users = manual.credentials.users;
	//console.log('loading hardcoded users',users);
} catch (e) {
	//console.log('Error - could not find hardcoded peers/users, this is okay if running in bluemix');
}




// view engine setup
alfabank.set('views', path.join(__dirname, 'views'));
alfabank.set('view engine', 'jade');



// uncomment after placing your favicon in /public
//alfabank.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
alfabank.use(logger('dev'));
alfabank.use(bodyParser.json());
alfabank.use(bodyParser.urlencoded({
	extended: false
}));
alfabank.use(cookieParser());
alfabank.use(express.static(path.join(__dirname, 'public')));






//alfabank.use('/', routes);

//alfabank.use('/users', users);
//alfabank.use('/dishes',dishrouter);
//alfabank.use('/leaders',leaderrouter);
//alfabank.use('/promos',promorouter);

//alfabank.use('/customer',customerRouter);
//alfabank.use('/employee',employeeRouter);



var mysql = require('mysql');
var shareddb = mysql.createPool({
	connectionLimit: 150,
	host: 'localhost',
	user: 'root',
	password: 'admin',
	database: 'shareddb'
});



var beneficiarybank = mysql.createPool({
	connectionLimit: 150,
	host: 'localhost',
	user: 'root',
	password: 'admin',
	database: 'beneficiarybank'
});



var applicantbank = mysql.createPool({
	connectionLimit: 150,
	host: 'localhost',
	user: 'root',
	password: 'admin',
	database: 'applicantbank'
});



var chaincode = null;
var ccdeployed = null;
var parseval = null;


var options = {
	network: {
		peers: [{
				"api_host": "192.168.99.100", //replace with your hostname or ip of a peer                                        //replace with your https port (optional, omit if n/a)
				"api_port": 7050, //replace with your http port
				"type": "peer",
				"id": "jdoe" //unique id of peer
			}

		], //lets only use the first peer! since we really don't need any more than 1
		users: [{
			"enrollId": "bob",
			"enrollSecret": "NOE63pEQbL25"
		}],
		//dump the whole thing, sdk will parse for a good one
		options: {
			quiet: true, //detailed debug messages on/off true/false
			tls: false, //should app to peer communication use tls?
			maxRetry: 1 //how many times should we retry register before giving up
		},
	},
	chaincode: {
		//zip_url: 'https://github.com/ibm-blockchain/marbles/archive/v2.0.zip',
		//subdirectroy name of chaincode after unzipped
		//git_url: 'http://gopkg.in/ibm-blockchain/marbles.v2/chaincode',                                                                                         //GO get http url

		git_url: 'https://github.com/bminchal/chain1/blob/master/git_code/',
		zip_url: 'https://github.com/bminchal/chain1/archive/master.zip',
		//unzip_dir: 'marbles-2.0/chaincode',
		unzip_dir: '/chain1-master/git_code/',

		deployed_name: '5850b594b0026eed8f9b8d81cd069690691c612094bd5474501d2e8862b6508179d6be140c09d8b48599d8a31d362637c6bdda06dc19739d3238fef3cf488f85',

		//hashed cc name from prev deployment, comment me out to always deploy, uncomment me when its already deployed to skip deploying again
		//deployed_name: '16e655c0fce6a9882896d3d6d11f7dcd4f45027fd4764004440ff1e61340910a9d67685c4bb723272a497f3cf428e6cf6b009618612220e1471e03b6c0aa76cb'
	}
};

// ---- Fire off SDK ---- //



//// Post method /////

// create todo and send back all todos after creation
//sdk will populate this var in time, lets give it high scope by creating it here
ibc.load(options, function (err, cc) { //parse/load chaincode, response has chaincode functions!
	if (err != null) {
		//console.log("options===>",options);

		//console.log('! looks like an error loading the chaincode or network, app will fail\n', err);
	} else {
		chaincode = cc;



		// ---- To Deploy or Not to Deploy ---- //
		if (!cc.details.deployed_name || cc.details.deployed_name === '') { //yes, go deploy
			cc.deploy('init', ['99'], {
				delay_ms: 30000
			}, function (e) { //delay_ms is milliseconds to wait after deploy for conatiner to start, 50sec recommended
				check_if_deployed(e, 1);
			});
		} else { //no, already deployed
			//console.log('chaincode summary file indicates chaincode has been previously deployed');
			check_if_deployed(null, 1);
		}
	}
});


//loop here, check if chaincode is up and running or not

function check_if_deployed(e, attempt) {
	if (e) {
		cb_deployed(e); //looks like an error pass it along
	}

	cb_deployed(null);


}


function cb_deployed(e) {
	if (e != null) {
		//look at tutorial_part1.md in the trouble shooting section for help
		//console.log('! looks like a deploy error, holding off on the starting the socket\n', e);
	} else {
		console.log('------------------------------------------ Service Up ------------------------------------------');

		ccdeployed = "deployed";

	}


}




alfabank.get('/logout', function (req, res) {
	req.logout();

});
alfabank.get('/api/wallets/', function (req, res) {
	console.log("response", res);
	res.send()

});
alfabank.get('/auth/logout/', function (req, res) {
	console.log("response", res);
	res.send()

});
//passport related get method ends






















alfabank.get('/', function (req, res) {
	res.sendFile(path.join(__dirname + '/index.html'));
});


alfabank.get('/auth/github',
passport.authenticate('github', { scope: [ 'user:email' ] }),
function(req, res){
	console.log("inside authentication");
  // The request will be redirected to GitHub for authentication, so this
  // function will not be called.
});

alfabank.get('/auth/github/callback', 
passport.authenticate('github', { failureRedirect: '/customerLogin' }),
function(req, res) {
  res.redirect('/');
});


alfabank.get('/me', function (req, res) {

	//res.send("ALFABank");
	res.send("ALPHABank");

});



























//get customer bank Guarantee
alfabank.get('/get-customer-bg/:name', function (req, res) {
	var param = req.params.name;
	var queryString = "select * from bankguarantee where status='requested' and applicantcustomer=?";
	//console.log(queryString);

	applicantbank.getConnection(function (err, connection) {
		if (err) {
			//connection.release();
			res.json({
				"code": 100,
				"status": "Error in connection database"
			});
			return;
		}
		connection.query(queryString, [param], function (err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			//console.log("LC VALUES ",rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;

			} else {
				res.send(rows);
				return
			}
			//connection.release();
		});
	});

});


//lc-amend-req/{lcAmendId}"






var alfa = alfabank.listen(3030, function () {


});
var host = alfa.address().address
var port1 = alfa.address().port
console.log("ALFA BANK listening at http://%s:%s", host, port1)
